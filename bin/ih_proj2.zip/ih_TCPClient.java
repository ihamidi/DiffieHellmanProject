// Programmer: Izhak Hamidi E01533340 
// Client program
// File name: ih_TCPClient.java

import java.io.*;
import java.net.*;
public class ih_TCPClient extends Thread {
    private static InetAddress host;
    /**
     * Main will check for arguments passed at command line.
     * Then will try to establish a connection with a Server using those arguments.
     * @param args
     */
    public static void main(String[] args) {
        //creating variables to store in arguments, and setting them to default values
        //hostnum adn username are set to defalt values
        String hostnum = "localhost";
        String user="";
        int portnum = 20450;
        boolean ureceived = false, preceived = false, hreceived = false;
        //checking if any argyment was passed
        if (args.length != 0) {
            //for every argument, check for -u,-p,-h
            for (int i = 0; i < args.length; i++)
                if (args[i].equals("-u") && !ureceived) {
                	user=args[i + 1];
                    System.out.println("username recieved");
                    ureceived = true;
                }
            else if (args[i].equals("-p") && !preceived) {
                //-p will alow next arg to be portnum
                portnum = Integer.parseInt(args[i + 1]);
                System.out.println("portnum recieved");
                preceived = true;
            } else if (args[i].equals("-h") && !hreceived) {
                //-h will allow next arg to be hostnum
                hostnum = args[i + 1];
                System.out.println("hosttnum recieved");
                hreceived = true;
            }
        }

        try {
            // Get server IP-address
            host = InetAddress.getByName(hostnum);
        } catch (UnknownHostException e) {
            System.out.println("Host ID not found!");
            System.exit(1);
        }
        Socket link = null;
        try {
            // Establish a connection to the server
            link = new Socket(host, portnum);
            
            //starting a send thread to manage client sending
            SendThread send = new SendThread(ureceived, user, link);
            //starting a get thread to manage client recieving.
            GetThread get = new GetThread(link);
            get.start();
            send.start();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
/**
 * SendThread is a class that has a thread which controls the messages the client sends.
 * @author hizha
 *
 */
class SendThread extends Thread {
    private boolean ureceived;
    private String us;
    private Socket link;
    /**
     * Constructor for sendtrhead
     * @param ureceived if user was received
     * @param us username
     * @param link the socket linked
     */
    SendThread(boolean ureceived, String us, Socket link) {
        this.ureceived = ureceived;
        this.us = us;
        this.link = link;
    }
    /**
     * Run will start a couple of writers adn connect them to the console
     * and SocketStream.
     * It will send messages to the server.
     */
    public void run() {
        try {
        	//initializing username to nothing
            String user = "";
            //starting a printwriter to send things to the server
            PrintWriter out = new PrintWriter(
                link.getOutputStream(), true);
            //bufferedreader to read in user input
            BufferedReader userEntry = new BufferedReader(new InputStreamReader(System.in));

            String message;
            //Prompting user for username
            if (!ureceived) {
                System.out.println("Username?:");
                user = userEntry.readLine();
                
            } else {
                user = us;
            }
            //sending username
            out.println(user);
            
            
            // Get data from the user and send it to the server
            do {
            	
            	//prompting user to enter a message, then sending it to the server
                System.out.print("Enter message:\n ");
                message = userEntry.readLine();
                out.println(user + ": " + message);
                //delaying the thread for 200 milliseconds
                Thread.sleep(200);

            } while (!message.equals("DONE"));
            out.println(user + " has left the room");
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


    }


}
/**
 * Get Thread is a class that extends thread which controls all incoming messages to the client.
 * @author hizha
 *
 */
class GetThread extends Thread {

    private Socket link;
    /**
     * GetThread constructer takes only the socket that is linked to the server
     * @param link
     */
    GetThread(Socket link) {

        this.link = link;
    }
    /**
     * Run will wait until a message is recieved, then output it to the clients console
     */
    public void run() {
        while (!link.isClosed())
            try {


                // Set up input streams for the connection
                BufferedReader in = new BufferedReader(
                    new InputStreamReader(link.getInputStream()));

                String response;
                String currline;

                // Receive the final report
                response = in .readLine();
                System.out.println(response);
                //reading in the final report
                while ((currline = in .readLine()) != null) {
                    System.out.println(currline);
                }

            }
        catch (IOException e) {
            e.printStackTrace();
        } finally {
        	//closing the connection.
            try {
                System.out.println("\n!!!!! Closing connection... !!!!!");
                link.close();
            } catch (IOException e) {
                System.out.println("Unable to disconnect!");
                System.exit(1);
            }

        }
    }
}